const express = require("express");
const { sequelize } = require("./models");
const authRoutes = require("./routes/authRoutes");
const postRoutes = require("./routes/posts");
const commentRoutes = require("./routes/comments");
const cors = require("cors");


const app = express();
const PORT = 5000;

app.use(express.json());
app.use(cors());

app.listen(PORT, async () => {
  console.log(`Serveur en cours d'exécution sur le port ${PORT}`);
  try {
    await sequelize.authenticate();
    console.log("Connexion à la base de données réussie !");
  } catch (error) {
    console.error("Erreur de connexion à la base de données :", error.message);
  }
});

app.use('/api/auth', authRoutes);
app.use('/api/posts', postRoutes);
app.use('/api/comments', commentRoutes);
