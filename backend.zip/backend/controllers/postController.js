const { Post } = require("../models");

exports.createPost = async (req, res) => {
  const { content } = req.body;
  try {
    const post = await Post.create({ content, userId: req.user.id });
    res.status(201).json({ message: "Post créé avec succès", post });
  } catch (error) {
    res.status(500).json({ message: "Erreur lors de la création du post", error: error.message });
  }
};

exports.updatePost = async (req, res) => {
    const post = await Post.findByPk(req.params.id);
    if (post.userId !== req.user.id) return res.status(403).json({ message: "Accès refusé" });
    try {
        post.content = req.body.content;
        await post.save();
        res.json(post);
    } catch (error) {
        res.status(500).json({ message: "Erreur lors de la mise à jour du post", error: error.message });
    }
};
  
  exports.deletePost = async (req, res) => {
    const post = await Post.findByPk(req.params.id);
    if (post.userId !== req.user.id) return res.status(403).json({ message: "Accès refusé" });
    try {
        await post.destroy();
        res.json({ message: "Post supprimé avec succès" });
    } catch (error) {
        res.status(500).json({ message: "Erreur lors de la suppression du post", error: error.message });
    }
  };
  exports.getAllPosts = async (req, res) => {
    try {
        const posts = await Post.findAll();
        res.json(posts);
    } catch (error) {
        res.status(500).json({ message: "Erreur lors de la récupération des posts", error: error.message });
    }
  };
